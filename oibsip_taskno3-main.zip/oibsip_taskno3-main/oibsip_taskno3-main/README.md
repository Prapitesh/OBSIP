# oibsip_taskno3

Simple Calculator Application using Java and XML

Check out this video:
https://youtu.be/f0XzsDBMrmE
